/*==============================================================================
 * Лаба 6. АЦП и внутренний термодатчик
 * МК K1921VG015
 *==============================================================================*/

#include <K1921VG015.h>
#include <stdint.h>
#include <stdio.h>
#include <system_k1921vg015.h>
#include "retarget.h"

/*-------------------- Настройки ----------------------------------------------*/
#define AREF          2.775f     // Реальное опорное напряжение на AREF
#define TEMP_CHANNEL  10         // Канал внутреннего термодатчика

/*-------------------- Глобальные переменные ----------------------------------*/
volatile uint8_t print_flag = 0;

/*-------------------- Прототипы ----------------------------------------------*/
void TMR32_IRQHandler(void);
/*-------------------- Прототипы ----------------------------------------------*/
void     TMR32_init(uint32_t period);
void     adcsar_init(void);
uint16_t Get_Temp_adc(void);
int8_t   Get_Temp_gradus(void);

/*==============================================================================
 * Инициализация таймера TMR32 (период 1 секунда)
 *==============================================================================*/
void TMR32_init(uint32_t period)
{
    RCU->CGCFGAPB_bit.TMR32EN = 1;
    RCU->RSTDISAPB_bit.TMR32EN = 1;

    TMR32->CAPCOM[0].VAL = period - 1;
    TMR32->CTRL_bit.MODE = 1;      // счёт от 0 до CAPCOM
    TMR32->IM = 2;                 // прерывание по совпадению

    PLIC_SetIrqHandler(Plic_Mach_Target,
                       IsrVect_IRQ_TMR32,
                       TMR32_IRQHandler);
    PLIC_SetPriority(IsrVect_IRQ_TMR32, 1);
    PLIC_IntEnable(Plic_Mach_Target, IsrVect_IRQ_TMR32);
}

/*==============================================================================
 * Инициализация АЦП и внутреннего термодатчика
 *==============================================================================*/
void adcsar_init(void)
{
    /* Питание АЦП */
    PMUSYS->ADCPWRCFG_bit.LDOEN  = 1;
    PMUSYS->ADCPWRCFG_bit.LVLDIS = 0;

    /* Тактирование АЦП */
    RCU->ADCSARCLKCFG_bit.CLKSEL = 1;
    RCU->ADCSARCLKCFG_bit.DIVN   = 0;
    RCU->ADCSARCLKCFG_bit.DIVEN = 0;
    RCU->ADCSARCLKCFG_bit.CLKEN = 1;
    RCU->ADCSARCLKCFG_bit.RSTDIS = 1;

    RCU->CGCFGAPB_bit.ADCSAREN  = 1;
    RCU->RSTDISAPB_bit.ADCSAREN = 1;

    /* Настройка АЦП */
    ADCSAR->ACTL_bit.SELRES = ADCSAR_ACTL_SELRES_12bit;
    ADCSAR->ACTL_bit.CALEN  = 1;
    ADCSAR->ACTL_bit.ADCEN  = 1;

    /* Секвенсор 0, программный запуск */
    ADCSAR->EMUX_bit.EM0 = ADCSAR_EMUX_EM0_SwReq;
    ADCSAR->SEQ[0].SRQSEL = TEMP_CHANNEL;

    /* Дополнительная задержка для термодатчика */
    ADCSAR->CHDELAY[TEMP_CHANNEL].CHDELAY = 2000;

    ADCSAR->SEQSYNC = ADCSAR_SEQSYNC_SYNC0_Msk;
    ADCSAR->SEQEN   = ADCSAR_SEQEN_SEQEN0_Msk;

    /* Включаем внутренний датчик температуры */
    TSENS->CTRL = 0x12;

    /* Ожидание готовности АЦП */
    while (!ADCSAR->ACTL_bit.ADCRDY) {}

    /* Пропуск первых измерений */
    Get_Temp_adc();
    Get_Temp_adc();
    Get_Temp_adc();
}

/*==============================================================================
 * Запуск измерения и чтение кода АЦП
 *==============================================================================*/
uint16_t Get_Temp_adc(void)
{
    ADCSAR->SEQSYNC_bit.GSYNC = 1;
    while (ADCSAR->BSTAT) {}
    while (!ADCSAR->RIS_bit.SEQRIS0) {}

    uint16_t val = ADCSAR->SEQ[0].SFIFO;
    ADCSAR->IC = ADCSAR_IC_SEQIC0_Msk;

    return val;
}

/*==============================================================================
 * Перевод кода АЦП в температуру (°C)
 *==============================================================================*/
int8_t Get_Temp_gradus(void)
{
    float voltage;
    uint16_t adc = Get_Temp_adc();

    voltage = (AREF * adc) / 4096.0f;
    voltage = 1.38f - voltage;

    return (int8_t)(voltage * 250.0f);
}

/*==============================================================================
 * Главная функция
 *==============================================================================*/
int main(void)
{
    SystemInit();
    SystemCoreClockUpdate();

    retarget_init();
    InterruptEnable();

    adcsar_init();

    printf("K1921VG015 SYSCLK = %d MHz\r\n",
           (int)(SystemCoreClock / 1000000));
    printf("Internal temperature sensor started\r\n");

    /* Таймер на 1 секунду */
    TMR32_init(SystemCoreClock);

    while (1)
    {
        if (print_flag)
        {
            print_flag = 0;
            printf("Temperature = %d C\r\n", Get_Temp_gradus());
        }
    }
}

/*==============================================================================
 * Обработчик прерывания таймера
 *==============================================================================*/
void TMR32_IRQHandler(void)
{
    print_flag = 1;
    TMR32->IC = 3;
}
