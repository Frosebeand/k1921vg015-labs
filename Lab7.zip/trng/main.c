#include <K1921VG015.h>
#include <stdint.h>
#include <system_k1921vg015.h>
#include "retarget.h"

// Функция для вывода числа в hex
void print_hex(uint32_t num) {
    const char hex_chars[] = "0123456789ABCDEF";

    retarget_put_char('0');
    retarget_put_char('x');

    for (int i = 7; i >= 0; i--) {
        uint8_t nibble = (num >> (i * 4)) & 0xF;
        retarget_put_char(hex_chars[nibble]);
    }
}

// Вывод приветствия и команд
void print_intro(void) {
    const char *msg = "=== TRNG Demo ===\n";
    while (*msg) retarget_put_char(*msg++);

    msg = "Commands:\n";
    while (*msg) retarget_put_char(*msg++);

    msg = "  r - Read 8 random numbers\n";
    while (*msg) retarget_put_char(*msg++);

    msg = "  s - Show status\n";
    while (*msg) retarget_put_char(*msg++);
}

int main(void) {
    SystemInit();
    retarget_init();

    print_intro();

    // Инициализация TRNG
    RCU->CGCFGAPB_bit.TRNGEN = 1;
    RCU->RSTDISAPB_bit.TRNGEN = 1;

    TRNG->CR = TRNG_CR_SOFTRST_Msk;  // программный сброс
    for (volatile uint32_t i = 0; i < 50000; i++);

    TRNG->WARMPERIOD = 0x200;
    TRNG->SAMPERIOD = 0x20;
    TRNG->CR = (1 << TRNG_CR_START_Pos);  // запуск генератора

    const char *msg = "TRNG started. Press key...\n";
    while (*msg) retarget_put_char(*msg++);

    while (1) {
        int c = retarget_get_char();

        if (c == 'r' || c == 'R') {
    retarget_put_char('\n');
    const char *label = "Random numbers:";
    while (*label) retarget_put_char(*label++);
    retarget_put_char('\n');

    // Массив для 8 случайных чисел
    uint32_t numbers[8];
    for (int i = 0; i < 8; i++) {
        // Ждем, пока FIFO не будет заполнен хотя бы на 1 слово
        volatile uint32_t timeout = 1000000;
        while (TRNG->FIFOLEV == 0 && timeout--) {
            __asm("nop");
        }

        if (TRNG->FIFOLEV > 0) {
            numbers[i] = TRNG->FIFO[0].FIFO; // Считываем число
            TRNG->FIFOLEV--; // Симулируем извлечение слова
        } else {
            numbers[i] = 0;  // если данных нет
        }
    }

    // Выводим все 8 чисел в hex
    for (int i = 0; i < 8; i++) {
        print_hex(numbers[i]);
        retarget_put_char(' ');
    }
    retarget_put_char('\n');
}
else if (c == 's' || c == 'S') {
    retarget_put_char('\n');
    const char *status_label = "Status: ";
    while (*status_label) retarget_put_char(*status_label++);

    uint32_t stat = TRNG->STAT;
    print_hex(stat);
    retarget_put_char('\n');

    const char *fifo_label = "FIFO level: ";
    while (*fifo_label) retarget_put_char(*fifo_label++);

    uint32_t fifo = TRNG->FIFOLEV;
    if (fifo == 0) {
        retarget_put_char('0');
    } else {
        char digits[10];
        int idx = 0;
        while (fifo > 0) {
            digits[idx++] = '0' + (fifo % 10);
            fifo /= 10;
        }
        for (int i = idx - 1; i >= 0; i--) {
            retarget_put_char(digits[i]);
        }
    }
    retarget_put_char('\n');
}

    }
}
