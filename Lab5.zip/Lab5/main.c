/*==============================================================================
 * Лабораторная работа №5
 * Режимы энергопотребления блока PMU
 * МК K1921VG015
 *==============================================================================*/

#include <K1921VG015.h>
#include <stdint.h>
#include <stdio.h>
#include <system_k1921vg015.h>
#include "retarget.h"

//-------------------- DEFINES --------------------------------------------------
#define GPIOA_ALL_Msk 0xFFFF
#define LEDS_MSK     0xFF00
#define LED0_MSK     (1 << 8)
#define LED1_MSK     (1 << 9)
#define LED2_MSK     (1 << 10)
#define LED3_MSK     (1 << 11)
#define LED4_MSK     (1 << 12)
#define LED5_MSK     (1 << 13)
#define LED6_MSK     (1 << 14)
#define LED7_MSK     (1 << 15)

#define IDLE_MODE     1
#define LP_IDLE_MODE  2
#define STOP_MODE     3
#define LP_STOP_MODE  4
#define POWEROFF_MODE 5

#define VL_1V0   0x12
#define VL_0V9   0x05
#define VL_1V2   0x14
#define VL_1V24  0x16
#define VL_1V3   0x19

//-------------------- GLOBALS --------------------------------------------------
char buff[120];
volatile uint32_t led_shift = LED0_MSK;
volatile uint8_t current_mode = IDLE_MODE;

//-------------------- PROTOTYPES ----------------------------------------------
void TMR32_IRQHandler(void);

//-------------------- UART -----------------------------------------------------
void Send_buff(char *a) {
    uint8_t i = 0;
    while ((i < 120) && (a[i] != 0)) {
        retarget_put_char(a[i]);
        i++;
    }
}

//-------------------- LED ------------------------------------------------------
void BSP_led_init(void) {
    RCU->CGCFGAHB_bit.GPIOAEN = 1;
    RCU->RSTDISAHB_bit.GPIOAEN = 1;
    GPIOA->OUTENSET = LEDS_MSK;
    GPIOA->DATAOUTCLR = LEDS_MSK;
}

void LED_ShowMode(uint8_t mode) {
    GPIOA->DATAOUTCLR = LEDS_MSK;
    switch (mode) {
        case IDLE_MODE:      GPIOA->DATAOUTSET = LED0_MSK; break;
        case LP_IDLE_MODE:   GPIOA->DATAOUTSET = LED1_MSK; break;
        case STOP_MODE:      GPIOA->DATAOUTSET = LED2_MSK; break;
        case LP_STOP_MODE:   GPIOA->DATAOUTSET = LED3_MSK; break;
        case POWEROFF_MODE:  break;
    }
}

//-------------------- TIMER ----------------------------------------------------
void TMR32_init(uint32_t period) {
    RCU->CGCFGAPB_bit.TMR32EN = 1;
    RCU->RSTDISAPB_bit.TMR32EN = 1;

    TMR32->CAPCOM[0].VAL = period - 1;
    TMR32->CTRL_bit.MODE = 1;
    TMR32->IM = 2;

    PLIC_SetIrqHandler(Plic_Mach_Target, IsrVect_IRQ_TMR32, TMR32_IRQHandler);
    PLIC_SetPriority(IsrVect_IRQ_TMR32, 1);
    PLIC_IntEnable(Plic_Mach_Target, IsrVect_IRQ_TMR32);
}

void ApplyTimerMode(uint8_t mode) {
    if (mode == IDLE_MODE || mode == LP_IDLE_MODE) {
        RCU->CGCFGAPB_bit.TMR32EN = 1; // таймер тактируется
    } else {
        RCU->CGCFGAPB_bit.TMR32EN = 0; // таймер полностью отключён
    }
}

//-------------------- PMU ------------------------------------------------------
void SelectPowerMode(uint8_t mode) {
    uint32_t tmp = PMURTC->WFI_ENTR & (PMURTC_WFI_ENTR_VL_Msk | PMURTC_WFI_ENTR_VH_Msk);

    PMURTC->WFI_PDEN_bit.EN = 1;
    ApplyTimerMode(mode);

    switch (mode) {
        case IDLE_MODE:
            PMURTC->WFI_ENTR = (1 << PMURTC_WFI_ENTR_LDO0EN_Pos) |
                               (1 << PMURTC_WFI_ENTR_LDO1EN_Pos) |
                               tmp;
            break;
        case LP_IDLE_MODE:
            PMURTC->WFI_ENTR = (1 << PMURTC_WFI_ENTR_LDO0EN_Pos) |
                               (1 << PMURTC_WFI_ENTR_LDO1EN_Pos) |
                               (1 << PMURTC_WFI_ENTR_LDO0LP_Pos) |
                               (1 << PMURTC_WFI_ENTR_LDO1LP_Pos) |
                               (VL_1V3 << PMURTC_WFI_ENTR_VH_Pos) |
                               (VL_1V24 << PMURTC_WFI_ENTR_VL_Pos) |
                               tmp;
            break;
        case STOP_MODE:
            PMURTC->WFI_ENTR = (1 << PMURTC_WFI_ENTR_LDO0EN_Pos) | tmp;
            break;
        case LP_STOP_MODE:
            PMURTC->WFI_ENTR = (1 << PMURTC_WFI_ENTR_LDO0EN_Pos) |
                               (1 << PMURTC_WFI_ENTR_LDO0LP_Pos) |
                               (VL_1V3 << PMURTC_WFI_ENTR_VH_Pos) |
                               (VL_1V24 << PMURTC_WFI_ENTR_VL_Pos) |
                               tmp;
            break;
        case POWEROFF_MODE:
            PMURTC->WFI_ENTR = tmp;
            break;
    }

    PMURTC->WFI_EXIT_bit.LDO0EN = 1;
    PMURTC->WFI_EXIT_bit.LDO1EN = 1;
    PMURTC->WFI_EXIT_bit.LDO0LP = 0;
    PMURTC->WFI_EXIT_bit.LDO1LP = 0;
    PMURTC->WFI_EXIT_bit.ALR = 1;

    __asm("WFI");
    __asm("NOP");
    __asm("NOP");
}

//-------------------- UART CONTROL --------------------------------------------
void ProcessUART(void) {
    int c = retarget_get_char();
    if (c < 0) return;

    switch (c) {
        case '1': current_mode = IDLE_MODE; break;
        case '2': current_mode = LP_IDLE_MODE; break;
        case '3': current_mode = STOP_MODE; break;
        case '4': current_mode = LP_STOP_MODE; break;
        case '5': current_mode = POWEROFF_MODE; break;
        default: return;
    }

    sprintf(buff, "\nSelect PMU mode %d\n", current_mode);
    Send_buff(buff);
    LED_ShowMode(current_mode);
    SelectPowerMode(current_mode);
}

//-------------------- INIT -----------------------------------------------------
void periph_init(void) {
    BSP_led_init();
    SystemInit();
    SystemCoreClockUpdate();
    retarget_init();

    sprintf(buff, "K1921VG015 SYSCLK = %d MHz\n", (int)(SystemCoreClock / 1000000));
    Send_buff(buff);

    Send_buff(
        "PMU modes:\n"
        "1 - IDLE\n"
        "2 - LP_IDLE\n"
        "3 - STOP\n"
        "4 - LP_STOP\n"
        "5 - POWEROFF\n"
    );
}

//-------------------- MAIN -----------------------------------------------------
int main(void) {
    periph_init();
    TMR32_init(SystemCoreClock >> 4);
    InterruptEnable();
    LED_ShowMode(current_mode);

    while (1) {
        ProcessUART();
    }
}

//-------------------- IRQ ------------------------------------------------------
void TMR32_IRQHandler(void) {
    GPIOA->DATAOUTTGL = led_shift;
    led_shift <<= 1;
    if (led_shift > LED7_MSK)
        led_shift = LED0_MSK;

    TMR32->IC = 3;
}
