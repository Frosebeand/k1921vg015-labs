#include <K1921VG015.h>
#include <stdint.h>
#include <system_k1921vg015.h>
#include "retarget.h"

//---------------- LED DEFINES -------------------------------------------------
#define LED5_MASK (1 << 12)   // PA12 - LED5
#define LED6_MASK (1 << 13)   // PA13 - LED6
#define LED7_MASK (1 << 14)   // PA14 - LED7
#define LED8_MASK (1 << 15)   // PA15 - LED8

#define WORKING_LEDS_MASK (LED5_MASK | LED6_MASK | LED7_MASK | LED8_MASK)


#define MIN_DELAY_MS 1100     
#define MAX_DELAY_MS 2800    

// Флаги состояния
uint8_t game_active = 0;
uint32_t signal_time = 0;
uint32_t reaction_start = 0;
uint32_t ms_counter = 0;

//---------------- ПРОСТЫЕ ЗАДЕРЖКИ --------------------------------------------
void delay_ms(uint32_t ms) {
    for(uint32_t i = 0; i < ms; i++) {
        // Упрощенная задержка
        for(uint32_t j = 0; j < 5000; j++) {
            __asm("NOP");
        }
        ms_counter++;
    }
}

//---------------- LED ФУНКЦИИ -------------------------------------------------
void init_leds(void) {
    RCU->CGCFGAHB_bit.GPIOAEN = 1;
    RCU->RSTDISAHB_bit.GPIOAEN = 1;
    GPIOA->OUTENSET = WORKING_LEDS_MASK;
    GPIOA->DATAOUT |= WORKING_LEDS_MASK;
    delay_ms(10);
}

void led_on(uint32_t led_mask) {
    GPIOA->DATAOUT &= ~led_mask;
}

void led_off(uint32_t led_mask) {
    GPIOA->DATAOUT |= led_mask;
}

void led_toggle(uint32_t led_mask) {
    GPIOA->DATAOUT ^= led_mask;
}

void all_leds_on(void) {
    GPIOA->DATAOUT &= ~WORKING_LEDS_MASK;
}

void all_leds_off(void) {
    GPIOA->DATAOUT |= WORKING_LEDS_MASK;
}

//---------------- TRNG ФУНКЦИИ ------------------------------------------------
void trng_init(void) {
    RCU->CGCFGAPB_bit.TRNGEN = 1;
    RCU->RSTDISAPB_bit.TRNGEN = 1;
    
    TRNG->CR = TRNG_CR_SOFTRST_Msk;
    delay_ms(10);
    
    TRNG->WARMPERIOD = 0x200;
    TRNG->SAMPERIOD = 0x20;
    TRNG->CR = (1 << TRNG_CR_START_Pos);
    
    delay_ms(10);
}

uint32_t get_random_number(void) {
    uint32_t timeout = 100000;
    while((TRNG->FIFOLEV == 0) && timeout--) {
        __asm("NOP");
    }
    
    if(TRNG->FIFOLEV > 0) {
        uint32_t val = TRNG->FIFO[0].FIFO;
        TRNG->FIFOLEV--;
        return val;
    }
    
    return ms_counter;
}

uint32_t generate_random_delay(void) {
    uint32_t random_val = get_random_number();
    uint32_t range = MAX_DELAY_MS - MIN_DELAY_MS + 1;
    return MIN_DELAY_MS + (random_val % range);
}

//---------------- UART ФУНКЦИИ ------------------------------------------------
void print_string(const char *str) {
    while (*str) {
        retarget_put_char(*str++);
    }
}

void print_number(uint32_t num) {
    char buffer[12];
    int i = 0;
    
    if (num == 0) {
        buffer[i++] = '0';
    } else {
        while (num > 0) {
            buffer[i++] = '0' + (num % 10);
            num /= 10;
        }
    }
    
    for (int j = i - 1; j >= 0; j--) {
        retarget_put_char(buffer[j]);
    }
}

int get_char_nonblock(void) {
    if (UART0->FR & UART_FR_RXFE_Msk) {
        return -1;
    }
    return UART0->DR;
}

void clear_uart_buffer(void) {
    while (!(UART0->FR & UART_FR_RXFE_Msk)) {
        volatile char c = UART0->DR;
        (void)c;
    }
}

//---------------- ИГРОВЫЕ ФУНКЦИИ ---------------------------------------------
void print_menu(void) {
    print_string("\n=== REACTION TIME GAME ===\n\n");
    print_string("Commands:\n");
    print_string("  s - Start game\n");
    print_string("  q - Quit\n\n");
}

void start_game(void) {
    if (game_active) {
        print_string("Game already running!\n");
        return;
    }
    
    clear_uart_buffer();
    all_leds_off();
    
    uint32_t random_delay = generate_random_delay();
    
    print_string("\n=== GAME STARTED ===\n");
    print_string("Wait for LEDs...\n");
    print_string("Then press ANY key!\n\n");
    print_string("Delay: ");
    print_number(random_delay);
    print_string(" ms\nWaiting");
    
    game_active = 1;
    signal_time = ms_counter + random_delay;
}

void update_game(void) {
    if (game_active != 1) return;
    
    static uint32_t last_blink = 0;
    
    // Мигаем LED6 каждые 250 мс
    if (ms_counter - last_blink >= 250) {
        led_toggle(LED6_MASK);
        last_blink = ms_counter;
    }
    
    // Проверяем, пора ли дать сигнал
    if (ms_counter >= signal_time) {
        led_off(LED6_MASK);
        all_leds_on();
        
        print_string(" SIGNAL!\n");
        print_string(">>> Press ANY key NOW! <<<\n");
        
        reaction_start = ms_counter;
        game_active = 2;
    }
}

void handle_reaction(void) {
    if (game_active != 2) return;
    
    uint32_t reaction_ms = ms_counter - reaction_start;
    all_leds_off();
    
    print_string("\n=== RESULT ===\n");
    print_string("Your reaction time: ");
    print_number(reaction_ms);
    print_string(" ms\n");
    
    if (reaction_ms < 180) print_string("Excellent\n");
    else if (reaction_ms < 280) print_string("Good\n");
    else if (reaction_ms < 400) print_string("Average\n");
    else print_string("Slow\n");
    
    print_string("=================\n\n");
    print_string("Press 's' to play again\n");
    
    game_active = 0;
}

//---------------- MAIN --------------------------------------------------------
int main(void) {
    SystemInit();
    SystemCoreClockUpdate();
    retarget_init();
    
    init_leds();
    trng_init();
    
    print_string("\n=== REACTION TIME GAME ===\n");
    
    // Быстрый тест
    all_leds_on();
    delay_ms(100);
    all_leds_off();
    delay_ms(100);
    
    print_menu();
    
    while (1) {
        if (game_active == 1) {
            update_game();
        }
        
        int key = get_char_nonblock();
        if (key != -1) {
            if (key == 's' || key == 'S') {
                if (game_active == 0) {
                    start_game();
                } else {
                    print_string("Finish current game first!\n");
                }
            }
            else if (key == 'q' || key == 'Q') {
                if (game_active == 0) {
                    print_string("\nGoodbye!\n");
                    while(1);
                } else {
                    print_string("Finish game first!\n");
                }
            }
            else {
                if (game_active == 2) {
                    handle_reaction();
                }
                else if (game_active == 1) {
                    print_string("\nToo early!\n");
                    all_leds_off();
                    game_active = 0;
                    print_string("Press 's' to restart\n");
                }
                else {
                    print_string("Press 's' to start game!\n");
                }
            }
        }
        
        delay_ms(1);
    }
    
    return 0;
}