/*==============================================================================
 * Лаба 9. RTC-будильник и пробуждение по времени
 * МК: K1921VG015
 *==============================================================================
 */

#include <K1921VG015.h>
#include <stdint.h>
#include <system_k1921vg015.h>

//---------------- LED DEFINES -------------------------------------------------
#define LEDS_MSK 0xF000
#define LED5_MSK (1 << 12)
#define LED6_MSK (1 << 13)
#define LED7_MSK (1 << 14)
#define LED8_MSK (1 << 15)

static const uint32_t led_masks[] = {
    LED5_MSK,
    LED6_MSK,
    LED7_MSK,
    LED8_MSK
};

#define ALARM_PERIOD 6

//---------------- DELAY -------------------------------------------------------
void delay(uint32_t a)
{
    while (a--) __asm("NOP");
}

//---------------- LED INIT ----------------------------------------------------
void BSP_led_init(void)
{
    RCU->CGCFGAHB_bit.GPIOAEN = 1;
    RCU->RSTDISAHB_bit.GPIOAEN = 1;
    GPIOA->OUTENSET = LEDS_MSK;
    GPIOA->DATAOUTSET = LEDS_MSK;
}

//---------------- POWER OFF ---------------------------------------------------
void Power_off(void)
{
    PMURTC->RTC_CFG1_bit.REGEN = 0;
    PMURTC->RTC_CFG1 |= PMURTC_RTC_CFG1_ALARMRST_Msk;

    __asm("WFI");
    __asm("NOP");
    __asm("NOP");
}

//---------------- MAIN --------------------------------------------------------
int main(void)
{
    uint32_t led_mask;

    SystemInit();
    SystemCoreClockUpdate();
    BSP_led_init();

    if (PMURTC->RTC_ALARM == 0)
    {
        PMURTC->RTC_CFG0_bit.EXTOSC = 1;
        PMURTC->RTC_REG[0].RTC_REG = 0;

        for (uint8_t i = 0; i < 3; i++)
        {
            GPIOA->DATAOUTCLR = LEDS_MSK;
            delay(SystemCoreClock >> 2);
            GPIOA->DATAOUTSET = LEDS_MSK;
            delay(SystemCoreClock >> 2);
        }
    }
    else
    {
        uint32_t led_index = PMURTC->RTC_REG[0].RTC_REG & 0x03;
        led_mask = led_masks[led_index];

        for (uint8_t i = 0; i < 2; i++)
        {
            GPIOA->DATAOUTTGL = led_mask;
            delay(SystemCoreClock >> 2);
            GPIOA->DATAOUTTGL = led_mask;
            delay(SystemCoreClock >> 2);
        }

        PMURTC->RTC_REG[0].RTC_REG = (PMURTC->RTC_REG[0].RTC_REG + 1) & 0x03;
    }

    GPIOA->DATAOUTSET = LEDS_MSK;
    PMURTC->RTC_ALARM = PMURTC->RTC_TIME + ALARM_PERIOD;

    Power_off();

    while (1)
    {
        __asm("WFI");
    }
}