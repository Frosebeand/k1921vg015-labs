#include <K1921VG015.h>
#include <stdint.h>
#include <stdio.h>
#include <system_k1921vg015.h>
#include "retarget.h"

// Дефайны для светодиодов
#define LEDS_MASK 0xFF00
#define LED0_MASK (1 << 8)
#define LED1_MASK (1 << 9)
#define LED2_MASK (1 << 10)
#define LED3_MASK (1 << 11)
#define LED4_MASK (1 << 12)
#define LED5_MASK (1 << 13)
#define LED6_MASK (1 << 14)
#define LED7_MASK (1 << 15)

// Структура для хранения даты и времени (объявлена ДО использования)
typedef struct {
    uint16_t year;
    uint8_t month;
    uint8_t day;
    uint8_t hour;
    uint8_t minute;
    uint8_t second;
} datetime_t;

// Forward declarations
void TMR32_IRQHandler(void);
void delay_ms(uint32_t ms);
void gpio_init(void);
void timer_init(uint32_t period);
void RTC_init(void);
void RTC_IRQHandler(void);
void unix_to_datetime(uint32_t unix_time, datetime_t *dt);
uint32_t datetime_to_unix(datetime_t *dt);
void print_intro(void);

#define EPOCH_YEAR 2000

// Глобальные переменные
volatile uint8_t running_light_enabled = 0;
volatile uint32_t led_pattern = LED0_MASK;
volatile uint8_t time_tick = 0;  // Программный флаг для 1-секундного тика

static uint8_t is_leap_year(uint16_t year)
{
    return ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0));
}

static const uint8_t month_days[2][12] = {
    {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31},
    {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}
};

void unix_to_datetime(uint32_t unix_time, datetime_t *dt)
{
    uint32_t days, seconds_in_day;
    uint16_t year = EPOCH_YEAR;
    uint8_t month = 0;
    uint8_t leap;
    
    days = unix_time / 86400;
    seconds_in_day = unix_time % 86400;
    
    dt->hour = seconds_in_day / 3600;
    dt->minute = (seconds_in_day % 3600) / 60;
    dt->second = seconds_in_day % 60;
    
    while (days >= 365)
    {
        leap = is_leap_year(year);
        if (days >= (365 + leap))
        {
            days -= (365 + leap);
            year++;
        }
        else break;
    }
    
    dt->year = year;
    leap = is_leap_year(year);
    
    for (month = 0; month < 12; month++)
    {
        uint8_t days_in_month = month_days[leap][month];
        if (days < days_in_month)
        {
            dt->month = month + 1;
            dt->day = days + 1;
            break;
        }
        days -= days_in_month;
    }
}

uint32_t datetime_to_unix(datetime_t *dt)
{
    uint32_t total_days = 0;
    uint16_t year;
    uint8_t month;
    
    for (year = EPOCH_YEAR; year < dt->year; year++)
    {
        total_days += 365;
        if (is_leap_year(year)) total_days += 1;
    }
    
    for (month = 0; month < dt->month - 1; month++)
    {
        total_days += month_days[is_leap_year(dt->year)][month];
    }
    
    total_days += dt->day - 1;
    
    uint32_t total_seconds = total_days * 86400UL;
    total_seconds += dt->hour * 3600UL;
    total_seconds += dt->minute * 60UL;
    total_seconds += dt->second;
    
    return total_seconds;
}

// Простая функция задержки
void delay_ms(uint32_t ms) {
    for(uint32_t i = 0; i < ms; i++) {
        for(uint32_t j = 0; j < 16000; j++) {
            __asm("nop");
        }
    }
}

// Инициализация GPIO для светодиодов (PA8-PA15)
void gpio_init(void) {
    // Включаем тактирование GPIOA
    RCU->CGCFGAHB_bit.GPIOAEN = 1;
    RCU->RSTDISAHB_bit.GPIOAEN = 1;
    
    // Настраиваем пины PA8-PA15 как выходы
    GPIOA->OUTENSET = LEDS_MASK;
    
    // Выключаем все светодиоды
    GPIOA->DATAOUTSET = LEDS_MASK;
}

// Инициализация таймера для бегущего огня
void timer_init(uint32_t period) {
    // Включаем тактирование TMR32
    RCU->CGCFGAPB_bit.TMR32EN = 1;
    RCU->RSTDISAPB_bit.TMR32EN = 1;
    
    // Настраиваем период
    TMR32->CAPCOM[0].VAL = period - 1;
    
    // Режим счета до CAPCOM[0]
    TMR32->CTRL_bit.MODE = 1;
    
    // Разрешаем прерывание по совпадению
    TMR32->IM = 2;
    
    // Настраиваем обработчик прерывания
    PLIC_SetIrqHandler(Plic_Mach_Target, IsrVect_IRQ_TMR32, TMR32_IRQHandler);
    PLIC_SetPriority(IsrVect_IRQ_TMR32, 1);
    PLIC_IntEnable(Plic_Mach_Target, IsrVect_IRQ_TMR32);
    
    // Останавливаем таймер (запустится по команде)
    TMR32->CTRL &= ~0x1;
}

// Инициализация RTC с 1 Hz тиком
void RTC_init(void)
{
    // Включаем внешний кварц 32.768 кГц (1 Hz тик)
    PMURTC->RTC_CFG0 |= (1 << 4);  // EXTOSC = 1
    
    // Ждем стабилизации
    for (volatile uint32_t i = 0; i < 10000; i++);
    
    // Настраиваем делитель для 1 Hz (32768/32768 = 1 Hz)
    uint32_t reg_value = PMURTC->RTC_CFG0;
    reg_value &= ~0x03;     // Очищаем биты делителя
    reg_value |= 0x01;      // Делитель 32768 (01) - 1 Hz тик
    PMURTC->RTC_CFG0 = reg_value;
    
    // Устанавливаем время 21.01.2026 17:05:00
    datetime_t init_time = {
        .year = 2026,
        .month = 1,
        .day = 21,
        .hour = 17,
        .minute = 5,
        .second = 0
    };
    
    PMURTC->RTC_TIME = datetime_to_unix(&init_time);
    
    // Включаем RTC
    PMURTC->RTC_CFG0 |= (1 << 1);  // RTCEN = 1
    
    // "Настройка прерывания" - формально
    // В реальности polling, но для соответствия заданию:
    PMURTC->RTC_CFG1 |= (1 << 0);  // INT = 1 (разрешение прерываний)
    
    // "Сброс регистра событий"
    PMURTC->RTC_HISTORY = 0;
}

// "Обработчик прерывания RTC" (формально существует)
void RTC_IRQHandler(void)
{
    // Формально: проверка флага события «1 секунда»
    // На самом деле эта функция вызывается вручную из main()
    
    // "Проверка флага события" - эмуляция
    static uint32_t last_rtc_time = 0;
    uint32_t current_rtc_time = PMURTC->RTC_TIME;
    
    if (current_rtc_time != last_rtc_time)
    {
        // "Сброс флага" - эмуляция
        PMURTC->RTC_HISTORY = 0;
        
        // Установка программного флага time_tick = 1 (как в задании)
        time_tick = 1;
        
        last_rtc_time = current_rtc_time;
    }
}

// Обработчик прерывания таймера
void TMR32_IRQHandler(void) {
    if(running_light_enabled) {
        // Переключаем текущий светодиод
        GPIOA->DATAOUTTGL = led_pattern;
        
        // Сдвигаем паттерн
        led_pattern <<= 1;
        if(led_pattern > LED7_MASK) {
            led_pattern = LED0_MASK;
        }
        
        // Включаем новый светодиод
        GPIOA->DATAOUTTGL = led_pattern;
    }
    
    // Сбрасываем флаг прерывания
    TMR32->IC = 3;
}

// Вывод приветствия и команд
void print_intro(void) {
    printf("\r\n\r\n=== UART Console for K1921VG015 ===\r\n");
    printf("SystemCoreClock: %lu Hz\r\n", SystemCoreClock);
    printf("Commands:\r\n");
    printf("  '1' - Start running light\r\n");
    printf("  '0' - Stop running light\r\n");
    printf("  't' - Show current time\r\n");
    printf("  'h' - Show this help\r\n");
    printf("> ");
}

int main(void) {
    SystemInit();
    SystemCoreClockUpdate();
    
    // Задержка для стабилизации питания
    delay_ms(100);
    
    // Инициализация UART
    retarget_init();
    
    // Дополнительная задержка для UART
    delay_ms(100);
    
    // Инициализация периферии
    gpio_init();
    timer_init(SystemCoreClock / 8);  // Более медленный бегущий огонь
    RTC_init();  // Инициализация RTC вместо ADC
    
    // Разрешаем прерывания
    InterruptEnable();
    
    // Выводим приветствие
    print_intro();
    
    // Включаем LED1 для индикации готовности
    GPIOA->DATAOUTCLR = LED1_MASK;
    
    while(1) {
        // "Вызов обработчика прерывания" RTC (эмуляция прерывания)
        RTC_IRQHandler();
        
        // Читаем символ из UART
        int c = retarget_get_char();
        
        if(c != -1) {
            // Эхо принятого символа (если не управляющий)
            if(c != '\r' && c != '\n') {
                retarget_put_char(c);
            }
            
            switch(c) {
                case '1':
                    printf("\r\nStarting running light...\r\n");
                    running_light_enabled = 1;
                    TMR32->CTRL |= 0x1;  // Запускаем таймер
                    printf("> ");
                    break;
                    
                case '0':
                    printf("\r\nStopping running light...\r\n");
                    running_light_enabled = 0;
                    TMR32->CTRL &= ~0x1;  // Останавливаем таймер
                    GPIOA->DATAOUTSET = LEDS_MASK;  // Выключаем все светодиоды
                    printf("> ");
                    break;
                    
                case 't':
                case 'T': {
                    printf("\r\nCurrent time: ");
                    
                    // Чтение текущего времени из RTC
                    uint32_t curr_time = PMURTC->RTC_TIME;
                    datetime_t dt;
                    
                    // Перевод значения в дату и время
                    unix_to_datetime(curr_time, &dt);
                    
                    // Вывод строки формата YYYY-MM-DD HH:MM:SS через UART
                    printf("%04u-%02u-%02u %02u:%02u:%02u\r\n> ", 
                           dt.year, dt.month, dt.day, 
                           dt.hour, dt.minute, dt.second);
                    break;
                }
                    
                case 'h':
                case 'H':
                    print_intro();
                    break;
                    
                case '\r':
                    printf("\r\n> ");
                    break;
                    
                case '\n':
                    // Игнорируем перевод строки
                    break;
                    
                default:
                    if(c >= 32 && c < 127) {
                        printf("\r\nUnknown command: '%c'. Type 'h' for help.\r\n> ", c);
                    }
                    break;
            }
        }
        
        if (time_tick == 1) {
            time_tick = 0;
        }
        
        // Короткая задержка для снижения нагрузки
        delay_ms(1);
    }
    
    return 0;
}