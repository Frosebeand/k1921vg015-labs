#include <K1921VG015.h>
#include <stdint.h>
#include <stdio.h>
#include <system_k1921vg015.h>
#include "retarget.h"

//-- Defines -------------------------------------------------------------------
#define LED0_MSK (1 << 8)
#define LEDS_MSK 0xFF00

char buff[120];

//-- Функция отправки строки ---------------------------------------------------
void Send_buff(char *a)
{
    uint8_t i = 0;
    while ((i < 120) && (a[i] != 0))
    {
        retarget_put_char(a[i]);
        i++;
    }
}

//-- Инициализация светодиодов -------------------------------------------------
void BSP_led_init(void)
{
    // Разрешаем тактирование GPIOA
    RCU->CGCFGAHB_bit.GPIOAEN = 1;
    // Включаем GPIOA
    RCU->RSTDISAHB_bit.GPIOAEN = 1;
    // Настраиваем пины 8-15 как выходы
    GPIOA->OUTENSET = LEDS_MSK;
    // Устанавливаем начальное состояние
    GPIOA->DATAOUTSET = LEDS_MSK;
}

//-- Инициализация периферии ---------------------------------------------------
void periph_init(void)
{
    BSP_led_init();
    SystemInit();
    SystemCoreClockUpdate();
    retarget_init();
}

//-- Главная функция -----------------------------------------------------------
int main(void)
{
    // Инициализация периферии
    periph_init();
    
    // Основной цикл программы
    while (1)
    {
        // Сюда студенты будут добавлять код для выполнения заданий
    }
    
    return 0;
}