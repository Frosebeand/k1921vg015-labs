#include <K1921VG015.h>
#include <stdint.h>
#include <system_k1921vg015.h>
#include "retarget.h"

//------------------------------ Settings --------------------------------------
#define PWM_FREQ_HZ      1000u

// TMR1 divider: DIV=3 => /8 (as in your code)
#define TMR1_DIV_CODE    3u
#define TMR1_DIV_VALUE   8u

// Choose PWM outmode. If duty looks inverted on real hardware, try 3 instead.
#define PWM_OUTMODE      7u

// Debug UART on/off
#define DEBUG_UART       1

//------------------------------ Globals ---------------------------------------
extern uint32_t SystemCoreClock;

static volatile uint8_t g_print_flag = 0;

//------------------------------ UART helpers (NO printf) ----------------------
#if DEBUG_UART
static void uart_putc(int c)
{
    retarget_put_char(c);
}

static void uart_crlf(void)
{
    uart_putc('\r');
    uart_putc('\n');
}

static void uart_puts(const char *s)
{
    while (*s) uart_putc((int)*s++);
}

static void uart_put_u32(uint32_t v)
{
    char t[11];
    int i = 0;

    if (v == 0)
    {
        uart_putc('0');
        return;
    }

    while (v > 0 && i < 10)
    {
        t[i++] = (char)('0' + (v % 10u));
        v /= 10u;
    }

    while (i--)
        uart_putc(t[i]);
}

static void uart_put_percent_from_val(uint16_t val, uint16_t period_ticks)
{
    // prints approx duty = (val+1)/period_ticks * 100
    uint32_t duty = ((uint32_t)(val + 1u) * 100u) / (uint32_t)period_ticks;
    uart_put_u32(duty);
    uart_putc('%');
}
#endif

//------------------------------ Utility ---------------------------------------
static uint16_t duty_to_val(uint16_t period_ticks, uint8_t duty_percent)
{
    if (duty_percent >= 100) return (uint16_t)(period_ticks - 1u);
    if (duty_percent == 0)   return 0;

    // rounded ticks_high = period_ticks * duty / 100
    uint32_t ticks_high = ((uint32_t)period_ticks * (uint32_t)duty_percent + 50u) / 100u;

    if (ticks_high == 0) ticks_high = 1;
    if (ticks_high >= period_ticks) ticks_high = period_ticks - 1u;

    // VAL is compare moment, often works as (ticks_high - 1)
    return (uint16_t)(ticks_high - 1u);
}

//------------------------------ Interrupt handler -----------------------------
void TMR32_IRQHandler(void)
{
    // 1 Hz tick -> ask main to print once
    g_print_flag = 1;

    // clear interrupt flags
    TMR32->IC = 3;
}

//------------------------------ Peripheral init -------------------------------
static void TMR32_init_1hz(void)
{
    // Enable TMR32 clock
    RCU->CGCFGAPB_bit.TMR32EN = 1;
    RCU->RSTDISAPB_bit.TMR32EN = 1;

    // Period = SystemCoreClock / 1Hz  (MODE=1: 0..CAPCOM0)
    TMR32->CAPCOM[0].VAL = (uint32_t)(SystemCoreClock - 1u);
    TMR32->CTRL_bit.MODE = 1;

    // Interrupt on CAPCOM0 match
    TMR32->IM = 2;

    // IRQ routing
    PLIC_SetIrqHandler(Plic_Mach_Target, IsrVect_IRQ_TMR32, TMR32_IRQHandler);
    PLIC_SetPriority(IsrVect_IRQ_TMR32, 0x1);
    PLIC_IntEnable(Plic_Mach_Target, IsrVect_IRQ_TMR32);

    // Start TMR32
    TMR32->CTRL |= (1u << 0);
}

static void TMR1_PWM_init(uint32_t pwm_freq_hz, uint8_t duty_pa8, uint8_t duty_pa9)
{
    // Enable TMR1 clock
    RCU->CGCFGAPB_bit.TMR1EN = 1;
    RCU->RSTDISAPB_bit.TMR1EN = 1;

    // Enable GPIOA clock
    RCU->CGCFGAHB_bit.GPIOAEN = 1;
    RCU->RSTDISAHB_bit.GPIOAEN = 1;

    // PA8/PA9 -> AF2 (TMR1)  (as in your code)
    GPIOA->ALTFUNCNUM_bit.PIN8 = 2;
    GPIOA->ALTFUNCNUM_bit.PIN9 = 2;
    GPIOA->ALTFUNCSET = (1u << 8) | (1u << 9);

// Timer settings
    TMR1->CTRL_bit.DIV  = TMR1_DIV_CODE; // /8
    TMR1->CTRL_bit.MODE = 1;            // 0..CAPCOM0

    // Compute period ticks: timer_clk = SystemCoreClock / divider
    uint32_t timer_clk = SystemCoreClock / TMR1_DIV_VALUE;
    uint32_t period_ticks = timer_clk / pwm_freq_hz;

    if (period_ticks < 2u) period_ticks = 2u;
    if (period_ticks > 0x10000u) period_ticks = 0x10000u; // 16-bit limit

    TMR1->CAPCOM[0].VAL = (uint16_t)(period_ticks - 1u);

    // CAPCOM[2] and CAPCOM[3] in compare mode
    TMR1->CAPCOM[2].CTRL_bit.CAP = 0;
    TMR1->CAPCOM[3].CTRL_bit.CAP = 0;

    // Same OUTMODE for both channels (simpler for students)
    TMR1->CAPCOM[2].CTRL_bit.OUTMODE = PWM_OUTMODE;
    TMR1->CAPCOM[3].CTRL_bit.OUTMODE = PWM_OUTMODE;

    uint16_t p = (uint16_t)period_ticks;
    TMR1->CAPCOM[2].VAL = duty_to_val(p, duty_pa8); // PA8
    TMR1->CAPCOM[3].VAL = duty_to_val(p, duty_pa9); // PA9

    // Start TMR1
    TMR1->CTRL |= (1u << 0);
}

static void periph_init(void)
{
    SystemInit();
    SystemCoreClockUpdate();

#if DEBUG_UART
    retarget_init();

    uart_puts("===================================="); uart_crlf();
    uart_puts("LAB3: PWM on TMR1 (PA8/PA9)");       uart_crlf();
    uart_puts("SystemCoreClock: "); uart_put_u32(SystemCoreClock); uart_crlf();
    uart_puts("PWM target freq: "); uart_put_u32(PWM_FREQ_HZ); uart_puts(" Hz"); uart_crlf();
    uart_puts("TMR1 divider   : /"); uart_put_u32(TMR1_DIV_VALUE);
    uart_puts(" (DIV code="); uart_put_u32(TMR1_DIV_CODE); uart_puts(")"); uart_crlf();
    uart_puts("PA8 duty       : 25%"); uart_crlf();
    uart_puts("PA9 duty       : 75%"); uart_crlf();
    uart_puts("OUTMODE        : "); uart_put_u32(PWM_OUTMODE); uart_crlf();
    uart_puts("Debug print    : once per second"); uart_crlf();
    uart_puts("===================================="); uart_crlf();
#endif
}

//------------------------------ Main ------------------------------------------
int main(void)
{
    periph_init();

    // Start timers
    TMR1_PWM_init(PWM_FREQ_HZ, 25, 75);
    TMR32_init_1hz();

    // Enable global interrupts
    InterruptEnable();

#if DEBUG_UART
    uart_puts("Running..."); uart_crlf();
#endif

    while (1)
    {
#if DEBUG_UART
        if (g_print_flag)
        {
            g_print_flag = 0;

            uint16_t cap0 = (uint16_t)TMR1->CAPCOM[0].VAL;
            uint16_t p = (uint16_t)(cap0 + 1u);

            uint16_t v2 = (uint16_t)TMR1->CAPCOM[2].VAL;
            uint16_t v3 = (uint16_t)TMR1->CAPCOM[3].VAL;

            uart_puts("--- PWM state ---"); uart_crlf();

            uart_puts("CAPCOM0 (period VAL): ");
            uart_put_u32(cap0);
            uart_puts("  (ticks="); uart_put_u32(p); uart_puts(")");
            uart_crlf();

            uart_puts("CAPCOM2 (PA8) VAL   : ");
            uart_put_u32(v2);
            uart_puts("  duty~");
            uart_put_percent_from_val(v2, p);
            uart_crlf();

            uart_puts("CAPCOM3 (PA9) VAL   : ");
            uart_put_u32(v3);
            uart_puts("  duty~");
            uart_put_percent_from_val(v3, p);
            uart_crlf();

            uart_puts("OUTMODE: ");
            uart_put_u32(PWM_OUTMODE);
            uart_crlf();
            uart_crlf();
        }
#endif
    }
}