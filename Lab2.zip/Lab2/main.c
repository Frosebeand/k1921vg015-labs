#include <K1921VG015.h>
#include <stdint.h>
#include <system_k1921vg015.h>

#define LEDS_MSK  0xFF00
#define LED0_MSK  (1u << 8)
#define LED7_MSK  (1u << 15)

void TMR32_IRQHandler(void);
volatile uint32_t led_shift;

static void BSP_led_init(void)
{
    RCU->CGCFGAHB_bit.GPIOAEN  = 1;
    RCU->RSTDISAHB_bit.GPIOAEN = 1;

    GPIOA->OUTENSET   = LEDS_MSK;
    GPIOA->DATAOUTSET = LEDS_MSK;
}

static void WAKEUP0_init(void)
{
    // 1. Настройка полярности (активный низкий уровень)
    PMURTC->RTC_WAKECFG_bit.WAKEPOL |= (1u << 0);
    
    // 2. Включение WAKEUP0
    PMURTC->RTC_WAKECFG_bit.WAKEEN |= (1u << 0);
    
    // 3. Сброс флага (если был установлен)
    PMURTC->RTC_HISTORY_bit.WAKE0 = 1;
    
    // 4. ВАЖНО: Ожидание стабилизации
    // WakeUp обычно требует несколько тактов для стабилизации
    for(volatile int i = 0; i < 1000; i++);
}

static void TMR32_init(uint32_t period)
{
    RCU->CGCFGAPB_bit.TMR32EN  = 1;
    RCU->RSTDISAPB_bit.TMR32EN = 1;

    TMR32->CAPCOM[0].VAL = period - 1;
    TMR32->CTRL_bit.MODE = 1;
    TMR32->IM = 2;

    PLIC_SetIrqHandler(Plic_Mach_Target, IsrVect_IRQ_TMR32, TMR32_IRQHandler);
    PLIC_SetPriority(IsrVect_IRQ_TMR32, 0x1);
    PLIC_IntEnable(Plic_Mach_Target, IsrVect_IRQ_TMR32);
}

static void periph_init(void)
{
    SystemInit();
    SystemCoreClockUpdate();
    BSP_led_init();
    WAKEUP0_init();
}

int main(void)
{
    periph_init();

    led_shift = LED0_MSK;

    uint32_t slow_period = SystemCoreClock >> 9;
    uint32_t fast_period = SystemCoreClock >> 12;
    uint8_t  fast = 0;

    TMR32_init(slow_period);
    InterruptEnable();

    // ВАЖНО: Сначала сбросим возможный старый флаг
    PMURTC->RTC_HISTORY_bit.WAKE0 = 1;
    
    // Небольшая задержка для стабилизации
    for(volatile int i = 0; i < 10000; i++);

    while (1)
    {
        // Проверяем флаг WAKE0
        if (PMURTC->RTC_HISTORY_bit.WAKE0 == 1)
        {
            // Сбрасываем флаг СРАЗУ
            PMURTC->RTC_HISTORY_bit.WAKE0 = 1;
            
            // Обработка нажатия
            fast = !fast;
            if (fast)
                TMR32->CAPCOM[0].VAL = fast_period - 1;
            else
                TMR32->CAPCOM[0].VAL = slow_period - 1;
            
            // Небольшая задержка для антидребезга
            for(volatile int i = 0; i < 100000; i++);
        }
    }
}

void TMR32_IRQHandler(void)
{
    GPIOA->DATAOUTTGL = led_shift;

    led_shift <<= 1;
    if (led_shift > LED7_MSK)
        led_shift = LED0_MSK;

    TMR32->IC = 3;
}