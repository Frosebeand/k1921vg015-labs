#include <K1921VG015.h>
#include <stdint.h>
#include <string.h>
#include <system_k1921vg015.h>
#include "retarget.h"

//---------------- LED DEFINES -------------------------------------------------
#define LED5_MASK (1 << 12)   // PA12 - RX done
#define LED6_MASK (1 << 13)   // PA13 - TX done
#define LED7_MASK (1 << 14)   // PA14 - ready
#define LED8_MASK (1 << 15)   // PA15 - unused

#define WORKING_LEDS_MASK (LED5_MASK | LED6_MASK | LED7_MASK | LED8_MASK)

//---------------- DMA / UART DEFINES -----------------------------------------
#define DMA_UART               UART0
#define DMA_TX_CH              8
#define UBUFF_SIZE             16

typedef enum {
    MODE_CMD = 0,
    MODE_INPUT_BLOCK,
    MODE_WAIT_TX
} app_mode_t;

//---------------- GLOBALS -----------------------------------------------------
uint8_t UBUFF[UBUFF_SIZE];
DMA_CtrlData_TypeDef DMA_CONFIGDATA __attribute__((aligned(1024)));

volatile uint32_t g_count = 0;
volatile app_mode_t g_mode = MODE_CMD;

//---------------- FORWARD DECLARATIONS ---------------------------------------
void delay_ms(uint32_t ms);
void gpio_init(void);
void dma_init(void);
void dma_prepare_tx(void);

void led_on(uint32_t mask);
void led_off(uint32_t mask);
void led_pulse(uint32_t mask);

void print_string(const char *str);
void print_buffer(uint8_t *buf, uint32_t len);
void clear_buffer(void);
void print_intro(void);

//---------------- SIMPLE DELAY ------------------------------------------------
void delay_ms(uint32_t ms)
{
    for (uint32_t i = 0; i < ms; i++) {
        for (uint32_t j = 0; j < 16000; j++) {
            __asm("nop");
        }
    }
}

//---------------- LED HELPERS -------------------------------------------------
void led_on(uint32_t mask)
{
    GPIOA->DATAOUTCLR = mask;   // active low
}

void led_off(uint32_t mask)
{
    GPIOA->DATAOUTSET = mask;   // active low
}

void led_pulse(uint32_t mask)
{
    led_on(mask);
    delay_ms(120);
    led_off(mask);
}

//---------------- GPIO INIT ---------------------------------------------------
void gpio_init(void)
{
    RCU->CGCFGAHB_bit.GPIOAEN = 1;
    RCU->RSTDISAHB_bit.GPIOAEN = 1;

    GPIOA->OUTENSET = WORKING_LEDS_MASK;

    // Сначала все выключить
    led_off(WORKING_LEDS_MASK);

    // LED7 = программа готова
    led_on(LED7_MASK);
}

//---------------- UART HELPERS ------------------------------------------------
void print_string(const char *str)
{
    while (*str) {
        retarget_put_char(*str++);
    }
}

void print_buffer(uint8_t *buf, uint32_t len)
{
    for (uint32_t i = 0; i < len; i++) {
        retarget_put_char((char)buf[i]);
    }
}

void clear_buffer(void)
{
    memset(UBUFF, 0, UBUFF_SIZE);
    g_count = 0;
}

//---------------- DMA INIT ----------------------------------------------------
void dma_init(void)
{
    DMA->BASEPTR = (uint32_t)&DMA_CONFIGDATA;
    DMA->CFG_bit.MASTEREN = 1;
}

//---------------- PREPARE TX DMA ----------------------------------------------
void dma_prepare_tx(void)
{
    DMA_UART->DMACR_bit.TXDMAE = 0;

    DMA_CONFIGDATA.PRM_DATA.CH[DMA_TX_CH].SRC_DATA_END_PTR = (uint32_t)&UBUFF[UBUFF_SIZE - 1];
    DMA_CONFIGDATA.PRM_DATA.CH[DMA_TX_CH].DST_DATA_END_PTR = (uint32_t)&DMA_UART->DR;

    DMA_CONFIGDATA.PRM_DATA.CH[DMA_TX_CH].CHANNEL_CFG_bit.SRC_SIZE   = DMA_CHANNEL_CFG_SRC_SIZE_Byte;
    DMA_CONFIGDATA.PRM_DATA.CH[DMA_TX_CH].CHANNEL_CFG_bit.SRC_INC    = DMA_CHANNEL_CFG_SRC_INC_Byte;
    DMA_CONFIGDATA.PRM_DATA.CH[DMA_TX_CH].CHANNEL_CFG_bit.DST_SIZE   = DMA_CHANNEL_CFG_DST_SIZE_Byte;
    DMA_CONFIGDATA.PRM_DATA.CH[DMA_TX_CH].CHANNEL_CFG_bit.DST_INC    = DMA_CHANNEL_CFG_DST_INC_None;
    DMA_CONFIGDATA.PRM_DATA.CH[DMA_TX_CH].CHANNEL_CFG_bit.R_POWER    = 0;
    DMA_CONFIGDATA.PRM_DATA.CH[DMA_TX_CH].CHANNEL_CFG_bit.N_MINUS_1  = UBUFF_SIZE - 1;
    DMA_CONFIGDATA.PRM_DATA.CH[DMA_TX_CH].CHANNEL_CFG_bit.CYCLE_CTRL = DMA_CHANNEL_CFG_CYCLE_CTRL_Basic;

    DMA->ENSET = (1u << DMA_TX_CH);
    DMA_UART->DMACR_bit.TXDMAE = 1;
}

//---------------- UI ----------------------------------------------------------
void print_intro(void)
{
    print_string("\r\n\r\n=== UART DMA LAB ===\r\n");
    print_string("Commands:\r\n");
    print_string("  h - help\r\n");
    print_string("  t - enter 16 bytes, then send them back via DMA\r\n");
    print_string("LEDs:\r\n");
    print_string("  LED5 - RX done pulse\r\n");
    print_string("  LED6 - TX done pulse\r\n");
    print_string("  LED7 - ready\r\n");
    print_string("> ");
}

//---------------- MAIN --------------------------------------------------------
int main(void)
{
    SystemInit();
    SystemCoreClockUpdate();

    delay_ms(100);
    retarget_init();
    delay_ms(100);

    gpio_init();
    dma_init();
    clear_buffer();

    print_intro();

    while (1) {
        if (g_mode == MODE_CMD) {
            int c = retarget_get_char();

            if (c != '\r' && c != '\n') {
                retarget_put_char((char)c);
            }

            switch (c) {
                case 'h':
                case 'H':
                    print_string("\r\n");
                    print_intro();
                    break;

                case 't':
                case 'T':
                    clear_buffer();
                    print_string("\r\nEnter exactly 16 bytes now:\r\n");
                    g_mode = MODE_INPUT_BLOCK;
                    break;

                case '\r':
                    print_string("\r\n> ");
                    break;

                case '\n':
                    break;

                default:
                    if (c >= 32 && c < 127) {
                        print_string("\r\nUse only 'h' or 't'.\r\n> ");
                    }
                    break;
            }
        }

        else if (g_mode == MODE_INPUT_BLOCK) {
            int c = retarget_get_char();

            if (c == '\r' || c == '\n') {
                continue;
            }

            retarget_put_char((char)c);

            if (g_count < UBUFF_SIZE) {
                UBUFF[g_count++] = (uint8_t)c;
            }

            if (g_count >= UBUFF_SIZE) {
                led_pulse(LED5_MASK);

                print_string("\r\nRX done. Buffer: ");
                print_buffer(UBUFF, UBUFF_SIZE);
                print_string("\r\n");

                print_string("Sending same 16 bytes back via DMA...\r\n");

                dma_prepare_tx();
                g_mode = MODE_WAIT_TX;
            }
        }

        else if (g_mode == MODE_WAIT_TX) {
            // Ждём окончания реальной передачи UART0
            if (DMA_UART->FR_bit.BUSY == 0) {
                DMA_UART->DMACR_bit.TXDMAE = 0;

                led_pulse(LED6_MASK);

                print_string("\r\nTX done.\r\n");
                print_string("Block finished. Press 't' for next transfer.\r\n> ");

                clear_buffer();
                g_mode = MODE_CMD;
            }
        }

        delay_ms(1);
    }

    return 0;
}