#include <K1921VG015.h>
#include <stdint.h>
#include <stdio.h>
#include <system_k1921vg015.h>
#include "retarget.h"

//---------------- LED DEFINES -------------------------------------------------
#define LED5_MASK (1 << 12)   // read pulse
#define LED6_MASK (1 << 13)   // erase pulse
#define LED7_MASK (1 << 14)   // write pulse / ready
#define LED8_MASK (1 << 15)   // unused

#define WORKING_LEDS_MASK (LED5_MASK | LED6_MASK | LED7_MASK | LED8_MASK)

//---------------- FLASH DEFINES -----------------------------------------------
// Смещение тестовой страницы внутри основной области Flash
#define FLASH_TEST_OFFSET   ((MEM_FLASH_PAGE_TOTAL - 1) * MEM_FLASH_PAGE_SIZE)

// Базовый адрес отображения Flash в адресное пространство ядра
#define FLASH_BASE_ADDR     0x80000000u

// Реальный адрес для чтения через указатель
#define FLASH_TEST_ADDR     (FLASH_BASE_ADDR + FLASH_TEST_OFFSET)

//---------------- GLOBALS -----------------------------------------------------
char buff[160];
uint8_t g_data_written = 0;

//---------------- FORWARD DECLARATIONS ----------------------------------------
void delay_ms(uint32_t ms);
void gpio_init(void);

void led_on(uint32_t mask);
void led_off(uint32_t mask);
void led_pulse(uint32_t mask);

void print_string(const char *str);
void send_buff(char *str);
void print_intro(void);

void flash_write_128b(uint32_t addr, uint32_t *data);
void flash_page_erase(uint32_t addr);

void flash_test_write_read(void);
void flash_erase_only(void);
void flash_write_only(void);
void flash_read_programmed_only(void);

//---------------- SIMPLE DELAY ------------------------------------------------
void delay_ms(uint32_t ms)
{
    for (uint32_t i = 0; i < ms; i++) {
        for (uint32_t j = 0; j < 16000; j++) {
            __asm("nop");
        }
    }
}

//---------------- LED HELPERS -------------------------------------------------
void led_on(uint32_t mask)
{
    GPIOA->DATAOUTCLR = mask;   // active low
}

void led_off(uint32_t mask)
{
    GPIOA->DATAOUTSET = mask;   // active low
}

void led_pulse(uint32_t mask)
{
    led_on(mask);
    delay_ms(120);
    led_off(mask);
}

//---------------- GPIO INIT ---------------------------------------------------
void gpio_init(void)
{
    RCU->CGCFGAHB_bit.GPIOAEN = 1;
    RCU->RSTDISAHB_bit.GPIOAEN = 1;

    GPIOA->OUTENSET = WORKING_LEDS_MASK;
    led_off(WORKING_LEDS_MASK);

    // LED7 горит в состоянии готовности
    led_on(LED7_MASK);
}

//---------------- UART HELPERS ------------------------------------------------
void print_string(const char *str)
{
    while (*str) {
        retarget_put_char(*str++);
    }
}

void send_buff(char *str)
{
    uint32_t i = 0;
    while ((i < 160) && (str[i] != 0)) {
        retarget_put_char(str[i]);
        i++;
    }
}

//---------------- FLASH LOW LEVEL ---------------------------------------------
// Для FLASH->ADDR используется смещение внутри Flash

void flash_write_128b(uint32_t addr, uint32_t *data)
{
    FLASH->ADDR = addr;
    FLASH->DATA[0].DATA = data[0];
    FLASH->DATA[1].DATA = data[1];
    FLASH->DATA[2].DATA = data[2];
    FLASH->DATA[3].DATA = data[3];

    FLASH->CMD = (0xC0DE << 16) | FLASH_CMD_WR_Msk;
    while (FLASH->STAT & 0x01)
        ;
}

void flash_page_erase(uint32_t addr)
{
    FLASH->ADDR = addr;
    FLASH->CMD = (0xC0DE << 16) | FLASH_CMD_ERSEC_Msk;
    while (FLASH->STAT & 0x01)
        ;
}

//---------------- FLASH COMMANDS ----------------------------------------------
void flash_erase_only(void)
{
    print_string("\r\n");
    sprintf(buff, "Erase page at offset 0x%X\r\n", FLASH_TEST_OFFSET);
    send_buff(buff);

    flash_page_erase(FLASH_TEST_OFFSET);
    led_pulse(LED6_MASK);

    g_data_written = 0;

    print_string("Erase done.\r\n> ");
}

void flash_write_only(void)
{
    uint32_t data[4];

    data[0] = 0x12345678;
    data[1] = 0xAAAA5555;
    data[2] = 0x5555AAAA;
    data[3] = 0x87654321;

    print_string("\r\n");
    sprintf(buff, "Write to offset 0x%X Data = 0x%X, 0x%X, 0x%X, 0x%X\r\n",
            FLASH_TEST_OFFSET, data[0], data[1], data[2], data[3]);
    send_buff(buff);

    flash_write_128b(FLASH_TEST_OFFSET, data);
    led_pulse(LED7_MASK);

    g_data_written = 1;

    print_string("Write done.\r\n> ");
}

void flash_read_programmed_only(void)
{
    if (!g_data_written) {
        print_string("\r\nNo programmed data to read.\r\n");
        print_string("Use 't' or 'w' first.\r\n> ");
        return;
    }

    print_string("\r\n");
    sprintf(buff, "Read from addr 0x%X Data = 0x%X, 0x%X, 0x%X, 0x%X\r\n",
            FLASH_TEST_ADDR,
            *((volatile uint32_t *)FLASH_TEST_ADDR),
            *((volatile uint32_t *)(FLASH_TEST_ADDR + 4)),
            *((volatile uint32_t *)(FLASH_TEST_ADDR + 8)),
            *((volatile uint32_t *)(FLASH_TEST_ADDR + 12)));
    send_buff(buff);

    led_pulse(LED5_MASK);
    print_string("> ");
}

void flash_test_write_read(void)
{
    uint32_t data[4];

    data[0] = 0x12345678;
    data[1] = 0xAAAA5555;
    data[2] = 0x5555AAAA;
    data[3] = 0x87654321;

    print_string("\r\n");
    sprintf(buff, "Write to offset 0x%X Data = 0x%X, 0x%X, 0x%X, 0x%X\r\n",
            FLASH_TEST_OFFSET, data[0], data[1], data[2], data[3]);
    send_buff(buff);

    flash_page_erase(FLASH_TEST_OFFSET);
    led_pulse(LED6_MASK);

    flash_write_128b(FLASH_TEST_OFFSET, data);
    led_pulse(LED7_MASK);

    g_data_written = 1;

    sprintf(buff, "Read from addr 0x%X Data = 0x%X, 0x%X, 0x%X, 0x%X\r\n",
            FLASH_TEST_ADDR,
            *((volatile uint32_t *)FLASH_TEST_ADDR),
            *((volatile uint32_t *)(FLASH_TEST_ADDR + 4)),
            *((volatile uint32_t *)(FLASH_TEST_ADDR + 8)),
            *((volatile uint32_t *)(FLASH_TEST_ADDR + 12)));
    send_buff(buff);

    led_pulse(LED5_MASK);
    print_string("> ");
}

//---------------- UI ----------------------------------------------------------
void print_intro(void)
{
    print_string("\r\n\r\n=== FLASH LAB 11 ===\r\n");
    print_string("Commands:\r\n");
    print_string("  h - help\r\n");
    print_string("  t - erase + write + read test\r\n");
    print_string("  e - erase Flash page\r\n");
    print_string("  w - write test data\r\n");
    print_string("  p - read programmed data\r\n");
    print_string("LEDs:\r\n");
    print_string("  LED5 - read pulse\r\n");
    print_string("  LED6 - erase pulse\r\n");
    print_string("  LED7 - write pulse / ready\r\n");
    print_string("> ");
}

//---------------- MAIN --------------------------------------------------------
int main(void)
{
    gpio_init();
    SystemInit();
    SystemCoreClockUpdate();
    gpio_init();

    delay_ms(100);
    retarget_init();
    delay_ms(100);

    sprintf(buff, "K1921VG015 SYSCLK = %d MHz\r\n", (int)(SystemCoreClock / 1000000));
    send_buff(buff);

    sprintf(buff, "UID[0] = 0x%X  UID[1] = 0x%X  UID[2] = 0x%X  UID[3] = 0x%X\r\n",
            PMUSYS->UID[0], PMUSYS->UID[1], PMUSYS->UID[2], PMUSYS->UID[3]);
    send_buff(buff);

    sprintf(buff, "PartNum = 0x%X\r\n", (uint16_t)(PMUSYS->UID[3] >> 16));
    send_buff(buff);

    print_intro();

    while (1) {
        int c = retarget_get_char();

        if (c != '\r' && c != '\n') {
            retarget_put_char((char)c);
        }

        switch (c) {
            case 'h':
            case 'H':
                print_string("\r\n");
                print_intro();
                break;

            case 't':
            case 'T':
                flash_test_write_read();
                break;

            case 'e':
            case 'E':
                flash_erase_only();
                break;

            case 'w':
            case 'W':
                flash_write_only();
                break;

            case 'p':
            case 'P':
                flash_read_programmed_only();
                break;

            case '\r':
                print_string("\r\n> ");
                break;

            case '\n':
                break;

            default:
                if (c >= 32 && c < 127) {
                    print_string("\r\nUse only 'h', 't', 'e', 'w' or 'p'.\r\n> ");
                }
                break;
        }

        delay_ms(1);
    }

    return 0;
}